# Godot Audio FFT (WIP)
 This project aims to create an FFT graph shader and a Waterfall Plot graph shader of the FFT of an audio in Godot 4.1
